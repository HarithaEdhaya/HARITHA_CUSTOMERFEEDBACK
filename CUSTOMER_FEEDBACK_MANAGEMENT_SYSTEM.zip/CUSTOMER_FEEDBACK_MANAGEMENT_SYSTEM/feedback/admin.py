from django.contrib import admin
from .models import Feedback  # Import your model(s)

# Register your model(s) to appear in the admin site
admin.site.register(Feedback)
